import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import java.awt.*;

import javax.swing.*;

public  class HotelManagementSystem extends JFrame implements ActionListener
{

	HotelManagementSystem()
	{
		setSize(1366,565);
		setLocation(100,100);
		
		ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icons/first.jpg"));
		JLabel image=new JLabel(i1);
		add(image);
		
		JLabel text=new JLabel("RAJ HOTEL  MANAGEMENT SYSTEM");
		
		text.setBounds(100,420,1000,90);
		text.setForeground(Color.white);
		text.setFont(new Font("serif",Font.PLAIN,30));
		image.add(text);
		
		JButton next=new JButton("NEXT");
		next.setBounds(1050,450,150,50);
		next.setBackground(Color.white);
		next.setForeground(Color.red);
		next.addActionListener(this);
		next.setFont(new Font("serif",Font.PLAIN,30));
		image.add(next);
		
		setVisible(true);
		
		
		while(true)
		{
			text.setVisible(false);
			try
			{
				Thread.sleep(500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			text.setVisible(true);
			
			try
			{
				Thread.sleep(500);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		setVisible(false);
		new Login();
	}
	
	public static void main(String[] args) 
	{
		new HotelManagementSystem();
		
	}

}
