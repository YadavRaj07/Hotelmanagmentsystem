
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.*;
import javax.swing.*;

public class AddRooms extends JFrame implements ActionListener
{
	JButton add,cancel;
	JTextField tfroom, tfprice ;
	JComboBox cbavailable,cbclean,cbtype;
	
	AddRooms()
	{
		getContentPane().setBackground(Color.white);
		setLayout(null);
		

		JLabel heading=new JLabel("Add Rooms");
		heading.setFont(new Font("Tahoma",Font.BOLD,18));
		heading.setBounds(150,20,200,20);
		add(heading);
		
		
		JLabel lblroomno=new JLabel("Room Number");
		lblroomno.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblroomno.setBounds(60,80,120,30);
		add(lblroomno);
		
		
		tfroom=new JTextField();
		tfroom.setBounds(200,80,150,30);
		add(tfroom);
		
		
		JLabel lblavailable=new JLabel("Available");
		lblavailable.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblavailable.setBounds(60,130,120,30);
		add(lblavailable);
		
		
		String availableOptions[]= {"Available","Occupied"};
		cbavailable =new JComboBox(availableOptions);
		cbavailable.setBounds(200,130,150,30);
		cbavailable.setBackground(Color.white);
		add(cbavailable);
		
		
		
		JLabel lblclean=new JLabel("Cleaning Status");
		lblclean.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblclean.setBounds(60,180,120,30);
		add(lblclean);
		
		
		String cleanOptions[]= {"Cleaned","Dirty"};
		cbclean =new JComboBox(cleanOptions);
		cbclean.setBounds(200,180,150,30);
		cbclean.setBackground(Color.white);
		add(cbclean);
		
		
		JLabel lblprice=new JLabel("Price");
		lblprice.setFont(new Font("Tahoma",Font.PLAIN,16));
		lblprice.setBounds(60,230,120,30);
		add(lblprice);
		
		
		tfprice=new JTextField();
		tfprice.setBounds(200,230,150,30);
		add(tfprice);
		
		
		JLabel lbltype=new JLabel("Bed Type");
		lbltype.setFont(new Font("Tahoma",Font.PLAIN,16));
		lbltype.setBounds(60,280,120,30);
		add(lbltype);
		
		
		String typeOptions[]= {"Single Bed","Double Bed"};
		cbtype=new JComboBox(typeOptions);
		cbtype.setBounds(200,280,150,30);
		cbtype.setBackground(Color.white);
		add(cbtype);
		
		
	    add=new JButton("Add Room");
		add.setForeground(Color.white);
		add.setBackground(Color.black);
		add.setBounds(60,350,130,30);
		add.addActionListener(this);
		add(add);
		
		cancel=new JButton("Cancel");
		cancel.setForeground(Color.white);
		cancel.setBackground(Color.black);
		cancel.setBounds(220,350,130,30);
		cancel.addActionListener(this);
		add(cancel);
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Icons\\twelve.jpg"));
		JLabel image=new JLabel(i1);
		image.setBounds(400,30,500,300);
		add(image);
		
		
		
		
		
		
		setBounds(330,200,940,470);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==add)
		{
			String roomnumber=tfroom.getText();
			String availability=(String) cbavailable.getSelectedItem();
			String status=(String) cbclean.getSelectedItem();
			String price=(String) tfprice.getText();
			String type=(String) cbtype.getSelectedItem();
			
			try
			{
				Conn conn=new Conn();
				String str = "insert into room values('"+roomnumber+"','"+ availability+"','"+status+"', '"+price+"','"+type+"')";
				
				
				conn.s.executeUpdate(str);
				
				JOptionPane.showMessageDialog(null, "New Room Added Succesfully");
				setVisible(false);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
		}
		else
		{
			setVisible(false);
		}
		
	}
	
	
	
	
	public static void main(String ar[])
	{
		new AddRooms();
	}
	
	
	
}
