import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.*;
import javax.swing.*;

public class AddEmployee  extends JFrame implements ActionListener
{
	JTextField tfname,tfmail,tfphone,tfage,tfsalary,tfadhhar;
	JRadioButton rbmale,rbfemale;
	JComboBox  cbjob;
	JButton submit;
	
	AddEmployee()
	{
		setLayout(null);
		
		JLabel lblname=new JLabel("NAME");
		lblname.setBounds(60,30,120,30);
		lblname.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lblname);
		
		 tfname=new JTextField();
		tfname.setBounds(200,30,150,30);
		add(tfname);
		
		
		JLabel lblage=new JLabel("AGE");
		lblage.setBounds(60,80,120,30);
		lblage.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lblage);
		
		tfage=new JTextField();
		tfage.setBounds(200,80,150,30);
		add(tfage);
		
		
		
		JLabel lblgender=new JLabel("GENDER");
		lblgender.setBounds(60,130,120,30);
		lblgender.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lblgender);
		
		rbmale=new JRadioButton("Male");
		rbmale.setBounds(200,130,70,30);
		rbmale.setFont(new Font("Tahoma", Font.PLAIN,14));
		rbmale.setBackground(Color.white);
		add(rbmale);
		
		
		rbfemale=new JRadioButton("Female");
		rbfemale.setBounds(280,130,70,30);
		rbfemale.setFont(new Font("Tahoma", Font.PLAIN,14));
		rbfemale.setBackground(Color.white);
		add(rbfemale);
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(rbmale);
		bg.add(rbfemale);
		
		

		JLabel lbljob=new JLabel("JOB");
		lbljob.setBounds(60,180,120,30);
		lbljob.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lbljob);
		
		
		String str[]= {"Front Desk Clerks","Porters","HouseKeeping","KitchenStaff","Room Service","Chefs","Waiters/Waitress","Manager","Accountant"};
		cbjob = new JComboBox(str);
		cbjob.setBounds(200,180,150,30);
		cbjob.setBackground(Color.white);
		add(cbjob);
		
		
		
		JLabel lblsalary=new JLabel("SALARY");
		lblsalary.setBounds(60,230,120,30);
		lblsalary.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lblsalary);
		
		tfsalary=new JTextField();
		tfsalary.setBounds(200,230,150,30);
		add(tfsalary);
		
		JLabel lblphone=new JLabel("PHONE");
		lblphone.setBounds(60,280,120,30);
		lblphone.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lblphone);
		
		tfphone=new JTextField();
		tfphone.setBounds(200,280,150,30);
		add(tfphone);
		
		JLabel lblmail=new JLabel("E-MAIL");
		lblmail.setBounds(60,330,120,30);
		lblmail.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add(lblmail);
		
		tfmail=new JTextField();
		tfmail.setBounds(200,330,150,30);
		add(tfmail);
		
		
		JLabel lbladhar=new JLabel("ADHHAR CARD");
		lbladhar.setBounds(60,380,120,30);
		 lbladhar.setFont(new Font("Tahoma",Font.PLAIN ,18));
		add( lbladhar);
		
		tfadhhar=new JTextField();
		tfadhhar.setBounds(200,380,150,30);
		add(tfadhhar);
		

		
		
		

		submit=new JButton("SUBMIT");
		submit.setBackground(Color.black);
		submit.setForeground(Color.white);
		submit.setBounds(200,430,150,30);
		submit.addActionListener(this);
		add(submit);
		
		
		ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("Icons//tenth.jpg"));
		Image i2=i1.getImage().getScaledInstance(450, 450, Image.SCALE_DEFAULT);
		ImageIcon i3=new ImageIcon(i2);
		
		JLabel image=new JLabel(i3);
		image.setBounds(380,60,450,370);
		add(image);
		
		
		
		getContentPane().setBackground(Color.white);
		setBounds(350,200,850,540);
		setVisible(true);
		
		
		
		
		
		
	}
	
	public static void main(String arr[])
	{
		new AddEmployee();
	}
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String name =tfname.getText();
		String age=tfage.getText();
		String salary=tfsalary.getText();
		String phone=tfphone.getText();
		String mail=tfmail.getText();
		String adhhar=tfadhhar.getText();
		
		String gender = null;
		if(rbmale.isSelected())
		{
			gender="Male";
			
		}
		else if(rbfemale.isSelected())
		{
			gender="Female";
		}
		
		String job=(String)cbjob.getSelectedItem();
		
		try
		{
			Conn conn=new Conn();
			
			String query="Insert into employee values('"+name+"','"+age+"','"+gender+"','"+job+"','"+salary+"','"+phone+"','"+mail+"','"+adhhar+"')";
			
			conn.s.executeUpdate(query);
			
			JOptionPane.showMessageDialog(null, "Employee Data added Succesfully");
			setVisible(false);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
	}

}
