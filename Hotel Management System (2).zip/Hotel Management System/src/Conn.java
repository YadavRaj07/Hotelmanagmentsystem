import java.sql.*;


public class Conn 
{
	Connection c;
	Statement s;

	Conn()
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			c=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotelmanagmentsystem","root","raj123");
			s=c.createStatement();
		}
		catch (ClassNotFoundException e) 
		{
			
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args)
	{
	
		

	}
}
	
	
	
	